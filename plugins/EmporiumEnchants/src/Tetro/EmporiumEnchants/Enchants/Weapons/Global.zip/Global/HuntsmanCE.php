<?php

# Namespaces
namespace xFrqendless\DivineCustomEnchants\Enchants\Weapons\Global;

# Pocketmine API
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\Event;
use pocketmine\inventory\Inventory;
use pocketmine\item\Item;
use pocketmine\player\Player;
use xFrqendless\DivineCustomEnchants\Core\CustomEnchant;
use xFrqendless\DivineCustomEnchants\Core\Types\ReactiveEnchantment;

# Used Files

# Enchantment Class
class HuntsmanCE extends ReactiveEnchantment
{

    # Register Enchantment
    public string $name = "Huntsman";
    public string $description = "Gives you a portion of the enemies money once killed.";
    public int $rarity = CustomEnchant::RARITY_LEGENDARY;
    public int $cooldownDuration = 0;
    public int $maxLevel = 10;
    public int $chance = 1;

    # Compatibility
    public int $usageType = CustomEnchant::TYPE_HAND;
    public int $itemType = CustomEnchant::ITEM_TYPE_WEAPON;

    # Reagents
    public function getReagent(): array
    {
        return [EntityDamageByEntityEvent::class];
    }

    # Enchantment
    public function react(Player $player, Item $item, Inventory $inventory, int $slot, Event $event, int $level, int $stack): void
    {
    }
}